function xyz2stl(varargin)
% convert .xyz file to .stl file
%
% xyz2stl(xyzPath)
%
% xyz2stl(xyzPath,'space filling')
%
% xyz2stl(xyzPath,'tube');
%
% xyz2stl(xyzPath,'tube','noh');

xyzPath = varargin{1};
stlPath = strrep(xyzPath,'.xyz','.stl');

[atoms,coordinates]=xyz2acr(xyzPath);
varargin=varargin(2:end);
[~,atoms_patch,bonds_patch]=showmol(atoms,coordinates,varargin{:});
atoms_patch(:,2)=[];
close();
atoms_number=size(atoms_patch,1);
bonds_number=size(bonds_patch,1);

molecule.vertices=atoms_patch{1,1}.vertices;
molecule.faces=atoms_patch{1,1}.faces;
for i=2:atoms_number
    atoms_patch{i,1}.faces=atoms_patch{i,1}.faces+size(molecule.vertices,1);
    molecule.vertices=[molecule.vertices;atoms_patch{i,1}.vertices];
    molecule.faces=[molecule.faces;atoms_patch{i,1}.faces];
end

if size(bonds_patch,1) > 0
    bonds_patch{1,1}.faces=bonds_patch{1,1}.faces+size(molecule.vertices,1);
    molecule.vertices=[molecule.vertices;bonds_patch{1,1}.vertices];
    molecule.faces=[molecule.faces;bonds_patch{1,1}.faces];
    for i=2:bonds_number
        bonds_patch{i,1}.faces=bonds_patch{i,1}.faces+size(molecule.vertices,1);
        molecule.vertices=[molecule.vertices;bonds_patch{i,1}.vertices];
        molecule.faces=[molecule.faces;bonds_patch{i,1}.faces];
    end
end

if size(molecule.faces, 2) == 4
    face_number = size(molecule.faces,1);
    new_faces = zeros(2*face_number,3);
    new_faces(1:2:end, :) = molecule.faces(:, [1 2 3]);
    new_faces(2:2:end, :) = molecule.faces(:, [1 3 4]);
    molecule.faces=new_faces;
end
stlwrite(stlPath,molecule);

end