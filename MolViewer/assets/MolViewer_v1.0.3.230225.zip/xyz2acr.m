function [atoms,coordinates]=xyz2acr(path)
% read .xyz file and output atoms & coordinates

load atomic_number.mat

fileID=fopen(path,'r');

if fileID == -1
    error('cannot open file');
end

xyz_file=textscan(fileID,'%s %f %f %f','HeaderLines',2);
atom_number=size(xyz_file{1,1},1);

atoms=zeros(atom_number,1);

for i=1:atom_number
    atoms(i)=find(strcmp(atomic_number,xyz_file{1,1}{i}));
end

coordinates=[xyz_file{1,2},xyz_file{1,3},xyz_file{1,4}];

fclose(fileID);

end