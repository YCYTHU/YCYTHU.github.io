function [axout,atoms_patch,bonds_patch]=showmol(varargin)
% showmol(atoms,corrdinates)
% atoms is an array containing the index of the atoms
% coordinates is a N x 3 matrix, where N is the number of atoms
% and each row represents the x, y, and z coordinates of an atom
%
% showmol(...,style)
% 'ball & stick' // 'space filling' // 'tube' // 'noh'
%
% showmol(ax,...)
%
% ax=showmol(...)

narginchk(2,inf);
if numel(varargin{1}) == 1 && ishghandle(varargin{1}(1)) && ...
        isequal(lower(char(get(varargin{1}(1),'type'))),'axes')
    ax=varargin{1};
    offs = 1;
else
    ax = [];
    offs = 0;
end

atoms=varargin{1+offs};
atom_number=length(atoms);
coordinates=varargin{2+offs};

if nargin - offs < 3
    style = 'ball & stick';
    option = {'normal'};
else
    style = varargin{3+offs};
    if nargin - offs < 4
        option = {'normal'};
    else
        option = varargin(4+offs:end);
    end
end

if size(coordinates,2) ~= 3 || atom_number < 1
    error('Coordinates should be N times 3 matris');
end

if size(coordinates,1) ~= atom_number
    error('Number of atoms does not match number of coordinates');
end

label = 0;
% show atoms labels

load showmol.mat
% atom color & covalent radii
load atomic_number.mat

switch style
    case {'ball & stick',''}
        ratio=0.2;
        % ratio = radius of balls / atoms' covalent radiis
        atoms_radius=ratio*covalent_radius;
        % atmoic radius
        bond_radius=0.02;
        % bond radius
        bond_length_ratio=1.15;
        % if distance between two atoms <
        % bond_length_ratio * sum of their covalent radiis
        % we assume they are bonded

    case 'space filling'
        bond_length_ratio=1.15;
        ratio=bond_length_ratio;
        atoms_radius=ratio*covalent_radius;
        bond_radius=0;

    case 'tube'
        ratio=1;
        bond_radius=0.1;
        atoms_radius=ratio*bond_radius*ones(size(covalent_radius));
        bond_length_ratio=1.15;

    otherwise
        error('wrong style');
end

for option_index=1:size(option,1)
    switch option{option_index}
        case 'normal'

        case 'noh'
            hydrogen=find(atoms==1);
            atoms(hydrogen)=[];
            atom_number=length(atoms);
            coordinates(hydrogen,:)=[];
        case 'labels'
            label=1;
        otherwise
            error('wrong option');
    end
end

sphere_smooth=100;
cylinder_smooth=20;
% more looks smoother
[xStdSph,yStdSph,zStdSph]=sphere(sphere_smooth);
[zStdCdr,yStdCdr,xStdCdr]=cylinder(bond_radius,cylinder_smooth);

if atom_number > 1 && bond_radius ~= 0
    pair_list=nchoosek(1:atom_number,2);
else
    pair_list=[];
end
% pair list

if ~isempty(pair_list)
    distance_list=sqrt(sum((coordinates(pair_list(:,1),:)-coordinates(pair_list(:,2),:)).^2,2));
    isbond=find(distance_list<bond_length_ratio*(covalent_radius(atoms(pair_list(:,1)))+covalent_radius(atoms(pair_list(:,2)))));
    bond_list=pair_list(isbond,:);
    distance_list=distance_list(isbond,:);
else
    bond_list=[];
end
% atom distance & bond list

atoms_patch=cell(atom_number,2);
bonds_patch=cell(length(bond_list),1);

ax=newplot(ax);
axes(ax);
set(ax,'Visible','off','DataAspectRatio',[1,1,1]);

hold on;
for i = 1:atom_number % draw atoms
    atom = atoms(i);
    x = coordinates(i,1);
    y = coordinates(i,2);
    z = coordinates(i,3);
    xSphere = xStdSph*atoms_radius(atom) + x;
    ySphere = yStdSph*atoms_radius(atom) + y;
    zSphere = zStdSph*atoms_radius(atom) + z;
    atom_sphere = surf(xSphere, ySphere, zSphere);
    set(atom_sphere,'FaceColor',atoms_color{atom},'EdgeColor','none','FaceLighting','gouraud');
    if label
        text(x+atoms_radius(atom),y+atoms_radius(atom),z+atoms_radius(atom),...
            [atomic_number{atom,1},num2str(i)],'Interpreter','latex','FontSize',12);
    end
    if nargout > 1
        atoms_patch{i,1}=surf2patch(atom_sphere);
        atoms_patch{i,2}=atomic_number{atom,1};
    end
end

if ~isempty(bond_list)
    for j = 1:size(bond_list,1) % draw bonds
        bond_vec1=coordinates(bond_list(j,1),:);
        bond_vec2=coordinates(bond_list(j,2),:);

        direction=(bond_vec2-bond_vec1)/distance_list(j);
        phi=atan2d(direction(2),direction(1))*(pi/180);
        theta=-asind(direction(3))*(pi/180);

        xCylinder=distance_list(j)*xStdCdr;
        rotz=[cos(phi),-sin(phi),0;sin(phi),cos(phi),0;0,0,1];
        roty=[cos(theta),0,sin(theta);0,1,0;-sin(theta),0,cos(theta)];
        yCylinder=zeros(size(yStdCdr));
        zCylinder=zeros(size(zStdCdr));
        for k=1:2
            rot_cylinder=rotz*roty*[xCylinder(k,:);yStdCdr(k,:);zStdCdr(k,:)];
            xCylinder(k,:)=rot_cylinder(1,:);
            yCylinder(k,:)=rot_cylinder(2,:);
            zCylinder(k,:)=rot_cylinder(3,:);
        end

        bond_cylinder=surf(xCylinder+bond_vec1(1),yCylinder+bond_vec1(2),zCylinder+bond_vec1(3));
        set(bond_cylinder,'EdgeColor','none','FaceColor','#EEE9E9','FaceLighting','gouraud');
        if nargout > 1
            bonds_patch{j,1}=surf2patch(bond_cylinder);
        end
    end
end

view(3);
camlight
hold off;

if nargout > 0
    axout = ax;
end

end