function cub_patch = showcub(varargin)
% draw isosurface of Gaussian type cube data and return cell of patch
%
% cub_patch = showcub(path,isovalue)
%
% cub_patch = showcub(path,isovalue,'nomolecule',____)

narginchk(2,inf);
if ~isstring(varargin{1}) && ~ischar(varargin{1})
    error('not a path');
end

if nargin > 2
    show_molecule=~strcmp(varargin{3},'nomolecule');
else
    show_molecule=1;
end

[xGrid,yGrid,zGrid,data,atoms,coordinates]=cub2mat(varargin{1});
isovalue=varargin{2};
iso_num=size(isovalue,1);
cub_patch=cell(iso_num,1);

hold on

for i=1:iso_num

    if isovalue(i) >= 0
        isocolor = '#9370DB';
    else
        isocolor = '#EEE9E9';
    end

    s=isosurface(xGrid,yGrid,zGrid,data,isovalue(i),varargin{4-show_molecule:end});
    p = patch(s);
    cub_patch{i,1} = {s;p};
    isonormals(xGrid,yGrid,zGrid,data,p);
    set(p,'FaceColor',isocolor,'EdgeColor','none','FaceLighting','gouraud');

end

if show_molecule
    showmol(atoms,coordinates);
else
    axis equal
    axis off
    view(3);
    camlight;
end

hold off

end