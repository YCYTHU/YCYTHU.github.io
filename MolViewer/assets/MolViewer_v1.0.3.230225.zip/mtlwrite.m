fid=fopen('atoms_color.mtl','w');
color=zeros(1,3);
for i=1:111
    color=st2rgb(atoms_color{i,1})/255;
    fprintf(fid,['newmtl ',atomic_number{i,1},'\n']);
    fprintf(fid,'Ka  1.0000  1.0000  1.0000\nKd  ');
    fprintf(fid,[num2str(color(1,1),'%.4f'),'  ',num2str(color(1,2),'%.4f'),'  ',num2str(color(1,3),'%.4f'),'\n']);
    fprintf(fid,'Ks  1.0000  1.0000  1.0000\nillum 2\nNs 100.0000\n\n');
end

fclose(fid);

function num=st2rgb(string)
    exchange_string='0123456789ABCDEF#';
    num=zeros(1,3);
    for i=1:3
        tempCoe1=find(exchange_string==string(i*2))-1;
        tempCoe2=find(exchange_string==string(i*2+1))-1;
        num(i)=16*tempCoe1+tempCoe2;
    end
end