function [xGradient,yGradient,zGradient]=gradcub(varargin)
% compute the gradient of gaussian type cube file
% 
% [xGradient,yGradient,zGradient]=gradcub(path)
%
% [xGradient,yGradient,zGradient]=gradcub(data)
%
% [xGradient,yGradient,zGradient]=gradcub(____,'normalize')

if isstring(varargin{1}) || ischar(varargin{1})
    [~,~,~,data]=cub2mat(varargin{1});
else
    if numel(size(varargin{1})) == 3
        data=varargin{1};
    else
        error('wrong input');
    end
end

[xGradient,yGradient,zGradient]=gradient(data);

if nargin == 2
    if strcmp(varargin{2},'normalize')
        gradient_norm=sqrt(xGradient.^2+yGradient.^2+zGradient.^2);
        xGradient=xGradient./gradient_norm;
        yGradient=yGradient./gradient_norm;
        zGradient=zGradient./gradient_norm;
    end
end

end