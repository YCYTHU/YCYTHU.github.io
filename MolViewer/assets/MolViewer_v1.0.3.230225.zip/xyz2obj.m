function xyz2obj(varargin)
% convert .xyz file to .obj file
%
% xyz2obj(xyzPath)
%
% xyz2obj(xyzPath,'space filling')
%
% xyz2obj(xyzPath,'tube');
%
% xyz2obj(xyzPath,'tube','noh');

xyzPath = varargin{1};
objPath = strrep(xyzPath,'.xyz','.obj');

fid=fopen(objPath,'w');
fprintf(fid,'mtllib atoms_materials.mtl\n');

[atoms,coordinates]=xyz2acr(xyzPath);
varargin=varargin(2:end);
[~,atoms_patch,bonds_patch]=showmol(atoms,coordinates,varargin{:});
close();
atoms_number=size(atoms_patch,1);
bonds_number=size(bonds_patch,1);

nvertices=0;
%molecule.vertices=atoms_patch{1,1}.vertices;
%molecule.faces=atoms_patch{1,1}.faces;

for i=1:atoms_number
    atom_patch=atoms_patch{i,1};
    atom_name=atoms_patch{i,2};
    atom_patch.faces=atom_patch.faces+nvertices;
    nvertices=nvertices+size(atom_patch.vertices,1);
    if size(atom_patch.faces, 2) == 4
        face_number = size(atom_patch.faces,1);
        new_faces = zeros(2*face_number,3);
        new_faces(1:2:end, :) = atom_patch.faces(:, [1 2 3]);
        new_faces(2:2:end, :) = atom_patch.faces(:, [1 3 4]);
        atom_patch.faces=new_faces;
    end

    fprintf(fid,['usemtl ',atom_name,'\n']);
    objwrite(fid,atom_patch.vertices,atom_patch.faces);
    %molecule.vertices=[molecule.vertices;atoms_patch{i,1}.vertices];
    %molecule.faces=[molecule.faces;atoms_patch{i,1}.faces];
end

if bonds_number > 0
    bonds_patch{1,1}.faces=bonds_patch{1,1}.faces+nvertices;
    nvertices=nvertices+size(bonds_patch{1,1}.vertices,1);
    bonds.vertices=bonds_patch{1,1}.vertices;
    bonds.faces=bonds_patch{1,1}.faces;

    for i=2:bonds_number
        bonds_patch{i,1}.faces=bonds_patch{i,1}.faces+nvertices;
        nvertices=nvertices+size(bonds_patch{i,1}.vertices,1);
        bonds.vertices=[bonds.vertices;bonds_patch{i,1}.vertices];
        bonds.faces=[bonds.faces;bonds_patch{i,1}.faces];
    end
    
    fprintf(fid,'usemtl bond\n');
    objwrite(fid,bonds.vertices,bonds.faces);
end

end