function [xGrid,yGrid,zGrid,data,varargout] = cub2mat(path)
% read gaussian type .cub files and output cube matrix 
% output molecule coordinates (alternative)

bohr_to_angstrom=0.529177249;

fileID = fopen(path);

if fileID == -1
    error('cannot open file');
end
% remove headers lines 1-2
for i=1:2
    fgetl(fileID);
end
% read cube parameters lines 3-6
grid_bohr = fscanf(fileID, '%f %f %f %f \n', [4,4])';
% read molecule configuration lines 7-(7+number of molecules)
coordinate_bohr = fscanf(fileID, '%f %f %f %f %f', [5,grid_bohr(1,1)])';

% to angstroms
grid = [grid_bohr(:,1),grid_bohr(:,2:end)*bohr_to_angstrom];
coordinate = [coordinate_bohr(:,1), coordinate_bohr(:,2:end) * bohr_to_angstrom];

varargout{1}=coordinate(:,1);
varargout{2}=coordinate(:,3:5);
varargout{3}=coordinate(:,2);

xstep = grid(2,2);
ystep = grid(3,3);
zstep = grid(4,4);
nxstep = grid(2,1);
nystep = grid(3,1);
nzstep = grid(4,1);
xLim = grid(1,2);
yLim = grid(1,3);
zLim = grid(1,4);

xaxis = [xLim:xstep:xLim+xstep*(nxstep-1)];
yaxis = [yLim:ystep:yLim+ystep*(nystep-1)];
zaxis = [zLim:zstep:zLim+zstep*(nzstep-1)];

% save file in matrix
data = zeros(nystep,nxstep,nzstep); % initialise 3D matrix
cubdata = fscanf(fileID, '%f %f %f %f %f %f', [6,Inf]); % read the rest of file
data_flat = reshape(cubdata,1,[]);

for i=1:nxstep
    for j=1:nystep
        for k=1:nzstep
            data(j,i,k) = data_flat(k+(j-1)*nzstep+(i-1)*nzstep*nystep);
        end
    end
end

[xGrid,yGrid,zGrid]=meshgrid(xaxis,yaxis,zaxis);

fclose(fileID);

end
